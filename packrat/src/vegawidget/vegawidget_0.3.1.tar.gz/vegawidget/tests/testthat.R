library(testthat)
library(vegawidget)

test_check("vegawidget")
