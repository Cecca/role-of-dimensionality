library(testthat)
library(furrr)

test_check("furrr")
