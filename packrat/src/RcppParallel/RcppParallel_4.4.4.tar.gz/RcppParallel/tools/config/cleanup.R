# Clean up files generated during configuration here.
# Use 'remove_file()' to remove files generated during configuration.
unlink("src/tbb/build/lib_release", recursive = TRUE)

