This Shiny application demonstrates girafe'selection mecanism. 

Select points on the graphic by clicking on it or by activating the lasso selection, 
selected points will be printed in a table.

Click the "Reset selection" to reset the selection or activate the lasso anti-selection.

