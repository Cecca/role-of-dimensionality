Shiny application for interactive map 

Select states on the graphic by clicking on them, selected states will be printed 
in the left panel.

