[![Travis build status](https://travis-ci.org/privefl/bigassertr.svg?branch=master)](https://travis-ci.org/privefl/bigassertr)
[![AppVeyor build status](https://ci.appveyor.com/api/projects/status/github/privefl/bigassertr?branch=master&svg=true)](https://ci.appveyor.com/project/privefl/bigassertr)
[![Coverage status](https://codecov.io/gh/privefl/bigassertr/branch/master/graph/badge.svg)](https://codecov.io/github/privefl/bigassertr?branch=master)

# bigassertr

Assertion tools.
