#!/bin/bash
grep -nE 'Failed|Warnings' *.out
