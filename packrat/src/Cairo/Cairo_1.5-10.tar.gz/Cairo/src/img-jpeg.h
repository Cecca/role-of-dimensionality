#ifndef __IMG_JPEG_H__
#define __IMG_JPEG_H__

int save_jpeg_file(void *buf, int w, int h, char *fn, int quality, int channels);

#endif
