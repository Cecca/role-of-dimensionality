#' @export
print.p_rope <- function(x, digits = 2, ...) {
  print.data.frame(x, digits = digits, ...) # TODO
}

