library(testthat)
library(directlabels)

test_check("directlabels")
