#' Deliberately NOT implemented. The users should use left_join instead
